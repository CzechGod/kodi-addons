# Kowesha

Kodi video plugin (`plugin.video.kowesha`) pro vyhledávání a přehrávání videí
z [Webshare.cz](https://webshare.cz). Cílová platforma: **Kodi 21 Omega**
(Python 3.11).

## Funkce

- **Přihlášení k účtu Webshare.cz** – uživatelské jméno a heslo se zadávají
  v nastavení doplňku; přihlašovací token se bezpečně cachuje a při vypršení
  se addon automaticky přihlásí znovu.
- **Vyhledávání** – zadání hledaného výrazu a výpis výsledků (název, velikost,
  náhled) se stránkováním. Přímo ve výsledcích lze **upravit dotaz** i
  **změnit způsob řazení** a hledání zopakovat.
- **Přehrávání** – výběr videa z výsledků spustí přehrávání přímého streamu.
- **Historie vyhledávání** – dřívější dotazy se pamatují a lze je znovu spustit,
  **upravit dotaz**, **změnit způsob řazení** nebo jednotlivě/hromadně smazat
  (přes kontextové menu).

## Struktura

```
plugin.video.kowesha/
├── addon.xml                     # metadata a vstupní bod
├── main.py                       # tenký vstupní bod (volá resources.lib.plugin)
├── resources/
│   ├── icon.png                  # ikona doplňku (512×512)
│   ├── settings.xml              # nastavení (údaje, počet výsledků, řazení)
│   ├── language/                 # lokalizace (cs_CZ, en_GB)
│   └── lib/
│       ├── plugin.py             # Kodi vrstva: router, pohledy, relace/token
│       ├── webshare.py           # klient API Webshare.cz (nezávislý na Kodi)
│       ├── md5crypt.py           # md5crypt pro přihlašovací šifru
│       ├── history.py            # perzistence historie vyhledávání
│       └── utils.py              # pomocné funkce
├── build_zip.py                  # skript pro sestavení instalovatelného ZIPu
└── tests/                        # unit testy čistého jádra i Kodi vrstvy
```

Čistá logika (`webshare`, `md5crypt`, `history`, `utils`) je záměrně nezávislá
na Kodi, takže ji lze testovat i mimo něj.

## Nastavení

Před prvním použitím vyplňte v **Nastavení doplňku** přihlašovací údaje:

- **Uživatelské jméno** a **Heslo** k účtu Webshare.cz.
- **Počet výsledků na stránku** (10–200, výchozí 50).
- **Výchozí řazení** (relevance / nejnovější / hodnocení / největší / nejmenší).
- **Zobrazit podrobný výpis chyby (stack trace)** – když nastane chyba, ukáže
  místo stručné notifikace okno s celým stacktrace (užitečné při hlášení chyb).
  Kompletní traceback se navíc vždy zapisuje do logu Kodi (`kodi.log`).

## Instalace pro vývoj

Kodi vyžaduje, aby se složka addonu jmenovala přesně podle jeho ID. Tento
repozitář je zároveň složkou addonu, proto ho do Kodi vložte (nebo
nasymlinkujte) pod názvem `plugin.video.kowesha`:

```bash
ln -s "$(pwd)" ~/.kodi/addons/plugin.video.kowesha
```

Poté v Kodi addon povolte (Nastavení → Doplňky → Moje doplňky).

## Sestavení instalovatelného ZIP

Pro distribuci a instalaci „ze souboru ZIP" vyrobí archiv se správnou strukturou
(jediná kořenová složka `plugin.video.kowesha`, bez vývojových souborů) skript
`build_zip.py`:

```bash
python3 build_zip.py
```

Archiv vznikne v `dist/plugin.video.kowesha-<verze>.zip` (verze i ID se čtou
z `addon.xml`). Skript používá jen standardní knihovnu Pythonu, takže nevyžaduje
externí nástroj `zip`. Volitelně lze zvolit jiný výstupní adresář:

```bash
python3 build_zip.py -o /tmp/out
```

Výsledný ZIP nainstalujete v Kodi přes **Nastavení → Doplňky → Instalovat ze
souboru ZIP** (nejdřív povolte *Neznámé zdroje*).

## Spuštění testů

```bash
python -m unittest discover -s tests
```

Testy nevyžadují běžící Kodi – moduly `xbmc*` jsou v testech nahrazeny atrapami.
