# -*- coding: utf-8 -*-
"""Kowesha – Kodi video plugin pro Webshare.cz.

Vstupní bod definovaný v ``addon.xml`` (``library="main.py"``). Kodi tento
soubor spouští znovu pro každou navigaci; veškerá logika je v balíčku
``resources.lib`` a odsud se jen zavolá ``run()``.
"""

import os
import sys

# Zajistí, že je kořen addonu na sys.path a balíček ``resources`` jde importovat.
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from resources.lib.plugin import run

if __name__ == "__main__":
    run()
