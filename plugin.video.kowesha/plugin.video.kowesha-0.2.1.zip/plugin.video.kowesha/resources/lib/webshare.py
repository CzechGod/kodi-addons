# -*- coding: utf-8 -*-
"""Klient pro (neoficiální) API Webshare.cz.

Modul je záměrně nezávislý na Kodi (nepoužívá ``xbmc*``), aby šel testovat
i mimo Kodi. Veškerá síťová komunikace prochází metodou :meth:`WebshareApi._request`,
kterou lze v testech snadno nahradit (monkeypatch).

API vrací XML odpovědi ve tvaru::

    <response>
        <status>OK</status>
        ...
    </response>

Při chybě je ``<status>`` různý od ``OK`` a odpověď obsahuje ``<code>``
a ``<message>``.
"""

import hashlib
from urllib.parse import urlencode
from urllib.request import Request, urlopen
from xml.etree import ElementTree as ET

from .md5crypt import md5crypt

BASE_URL = "https://webshare.cz/api/"
USER_AGENT = "Kowesha/1.0 (+https://github.com/kowesha)"
DEVICE_UUID = "kowesha-kodi"

# Podporované způsoby řazení výsledků (hodnota API -> není lokalizováno zde).
SORT_METHODS = ("relevance", "recent", "rating", "largest", "smallest")


class WebshareError(Exception):
    """Obecná chyba vrácená API Webshare."""

    def __init__(self, message, code=None):
        super().__init__(message)
        self.message = message
        self.code = code


class AuthenticationError(WebshareError):
    """Přihlašovací údaje jsou neplatné nebo token vypršel."""


class WebshareApi:
    """Tenký klient nad Webshare.cz API."""

    def __init__(self, token=None, base_url=BASE_URL):
        self.token = token
        self.base_url = base_url

    # -- Nízkoúrovňová komunikace ------------------------------------------
    def _request(self, endpoint, data):
        """Provede HTTP POST a vrátí tělo odpovědi jako text.

        Vydělené do samostatné metody kvůli testovatelnosti.
        """
        body = urlencode(data).encode("utf-8")
        request = Request(
            "{0}{1}/".format(self.base_url, endpoint),
            data=body,
            headers={
                "User-Agent": USER_AGENT,
                "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
                "Accept": "text/xml; charset=UTF-8",
            },
        )
        with urlopen(request, timeout=30) as response:
            return response.read().decode("utf-8")

    def _call(self, endpoint, data):
        """Zavolá endpoint, zparsuje XML a ověří stav odpovědi."""
        raw = self._request(endpoint, data)
        try:
            root = ET.fromstring(raw)
        except ET.ParseError as exc:
            raise WebshareError("Neplatná odpověď serveru: {0}".format(exc))
        self._check_status(root)
        return root

    @staticmethod
    def _check_status(root):
        status = (root.findtext("status") or "").upper()
        if status == "OK":
            return
        message = root.findtext("message") or "Neznámá chyba"
        code = root.findtext("code")
        # Chyby týkající se přihlášení / tokenu hlásíme zvlášť.
        lowered = message.lower()
        if any(word in lowered for word in ("token", "login", "přihlá", "prihla", "heslo", "password")):
            raise AuthenticationError(message, code)
        raise WebshareError(message, code)

    # -- Přihlášení --------------------------------------------------------
    def _salt(self, username):
        root = self._call("salt", {"username_or_email": username})
        return root.findtext("salt") or ""

    def login(self, username, password):
        """Přihlásí se a uloží ``self.token``; vrací získaný token."""
        if not username or not password:
            raise AuthenticationError("Chybí uživatelské jméno nebo heslo")
        salt = self._salt(username)
        encrypted = hashlib.sha1(
            md5crypt(password, salt).encode("utf-8")
        ).hexdigest()
        digest = hashlib.md5(
            ("{0}:Webshare:{1}".format(username, password)).encode("utf-8")
        ).hexdigest()
        root = self._call(
            "login",
            {
                "username_or_email": username,
                "password": encrypted,
                "digest": digest,
                "keep_logged_in": 1,
            },
        )
        self.token = root.findtext("token") or ""
        if not self.token:
            raise AuthenticationError("Server nevrátil přihlašovací token")
        return self.token

    def is_token_valid(self):
        """Vrátí ``True``, pokud je aktuální token platný."""
        if not self.token:
            return False
        try:
            self._call("user_data", {"wst": self.token})
            return True
        except WebshareError:
            return False

    def logout(self):
        if not self.token:
            return
        try:
            self._call("logout", {"wst": self.token})
        except WebshareError:
            pass
        self.token = None

    # -- Vyhledávání a odkazy ---------------------------------------------
    def search(self, query, sort="relevance", limit=50, offset=0, category="video"):
        """Vyhledá soubory. Vrací ``dict`` s klíči ``total`` a ``files``."""
        if not self.token:
            raise AuthenticationError("Nejste přihlášeni")
        root = self._call(
            "search",
            {
                "what": query,
                "category": category,
                "sort": sort if sort in SORT_METHODS else "relevance",
                "limit": int(limit),
                "offset": int(offset),
                "wst": self.token,
                "maybe_removed": "true",
            },
        )
        files = [self._parse_file(node) for node in root.findall("file")]
        total = int(root.findtext("total") or len(files))
        return {"total": total, "files": files}

    def file_link(self, ident, file_password=None):
        """Vyřeší přímou (streamovatelnou) URL pro daný ``ident``."""
        if not self.token:
            raise AuthenticationError("Nejste přihlášeni")
        data = {
            "ident": ident,
            "wst": self.token,
            "download_type": "video_stream",
            "device_uuid": DEVICE_UUID,
            "force_https": 1,
        }
        if file_password:
            data["password"] = hashlib.md5(
                file_password.encode("utf-8")
            ).hexdigest()
        root = self._call("file_link", data)
        link = root.findtext("link")
        if not link:
            raise WebshareError("Server nevrátil odkaz na soubor")
        return link

    @staticmethod
    def _parse_file(node):
        """Převede ``<file>`` uzel na jednoduchý ``dict``."""

        def text(tag, default=""):
            value = node.findtext(tag)
            return value if value is not None else default

        def integer(tag, default=0):
            try:
                return int(node.findtext(tag))
            except (TypeError, ValueError):
                return default

        return {
            "ident": text("ident"),
            "name": text("name"),
            "type": text("type"),
            "img": text("img"),
            "stripe": text("stripe"),
            "size": integer("size"),
            "positive_votes": integer("positive_votes"),
            "negative_votes": integer("negative_votes"),
            "password": text("password") in ("1", "true"),
        }
