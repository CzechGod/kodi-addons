# -*- coding: utf-8 -*-
"""Kodi glue pro plugin.video.kowesha.

Obsahuje směrování (router), jednotlivé pohledy (kořenové menu, výsledky
vyhledávání, historie) a správu přihlašovací relace (token cache). Čistá
logika (API klient, md5crypt, historie, formátování) žije v ostatních
modulech v ``resources/lib`` a je nezávislá na Kodi.
"""

import os
import sys
import traceback
from urllib.parse import parse_qsl, urlencode

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

from .history import SearchHistory
from .utils import human_size
from .webshare import (
    SORT_METHODS,
    AuthenticationError,
    WebshareApi,
    WebshareError,
)

_ADDON = xbmcaddon.Addon()
_ADDON_ID = _ADDON.getAddonInfo("id")
_HANDLE = int(sys.argv[1])
_BASE_URL = sys.argv[0]

# Mapování hodnot řazení na ID lokalizovaných řetězců.
_SORT_LABEL_IDS = {
    "relevance": 30023,
    "recent": 30024,
    "rating": 30025,
    "largest": 30026,
    "smallest": 30027,
}


def _log(message, level=xbmc.LOGINFO):
    xbmc.log("[{0}] {1}".format(_ADDON_ID, message), level)


def L(string_id):
    """Vrátí lokalizovaný řetězec addonu."""
    return _ADDON.getLocalizedString(string_id)


def sort_label(sort):
    return L(_SORT_LABEL_IDS.get(sort, 30023))


def build_url(**kwargs):
    """Sestaví plugin URL s parametry akce (bezpečně URL-enkóduje)."""
    return "{0}?{1}".format(_BASE_URL, urlencode(kwargs))


def notify(message, icon=xbmcgui.NOTIFICATION_INFO):
    xbmcgui.Dialog().notification(_ADDON.getAddonInfo("name"), message, icon)


def _show_exception(exc):
    """Zaloguje celý stacktrace a podle nastavení ho ukáže uživateli.

    Kompletní traceback se vždy zapíše do logu Kodi (``kodi.log``). Když je
    v nastavení zapnuté *ladění* (``debug``), zobrazí se uživateli celý
    stacktrace v okně s textem; jinak dostane jen stručnou chybovou notifikaci.
    """
    trace = traceback.format_exc()
    _log(trace, xbmc.LOGERROR)
    message = str(getattr(exc, "message", "") or exc) or exc.__class__.__name__
    if _ADDON.getSettingBool("debug"):
        xbmcgui.Dialog().textviewer(
            "{0} \u2013 {1}".format(_ADDON.getAddonInfo("name"), L(30060)),
            trace,
        )
    else:
        notify(message, xbmcgui.NOTIFICATION_ERROR)


def _profile_dir():
    path = xbmcvfs.translatePath(_ADDON.getAddonInfo("profile"))
    if not os.path.isdir(path):
        os.makedirs(path, exist_ok=True)
    return path


def _results_limit():
    limit = _ADDON.getSettingInt("results_limit")
    return limit if limit and limit > 0 else 50


def _default_sort():
    sort = _ADDON.getSettingString("default_sort")
    return sort if sort in SORT_METHODS else "relevance"


# --------------------------------------------------------------------------
# Přihlašovací relace / správa tokenu
# --------------------------------------------------------------------------
class Session:
    """Drží API klienta a stará se o (opětovné) přihlášení a cache tokenu."""

    def __init__(self):
        self._token_path = os.path.join(_profile_dir(), "token")
        self.api = WebshareApi(token=self._read_token())

    def _read_token(self):
        try:
            with open(self._token_path, "r", encoding="utf-8") as handle:
                return handle.read().strip() or None
        except OSError:
            return None

    def _write_token(self, token):
        try:
            with open(self._token_path, "w", encoding="utf-8") as handle:
                handle.write(token or "")
        except OSError as exc:
            _log("Nelze uložit token: {0}".format(exc), xbmc.LOGWARNING)

    def _login_from_settings(self):
        username = _ADDON.getSettingString("username")
        password = _ADDON.getSettingString("password")
        if not username or not password:
            raise AuthenticationError(L(30051))  # vyplňte údaje v nastavení
        _log("Přihlašuji uživatele k Webshare.cz")
        self.api.login(username, password)
        self._write_token(self.api.token)

    def call(self, method_name, *args, **kwargs):
        """Zavolá metodu API a při vypršení tokenu se jednou znovu přihlásí."""
        if not self.api.token:
            self._login_from_settings()
        method = getattr(self.api, method_name)
        try:
            return method(*args, **kwargs)
        except AuthenticationError:
            _log("Token neplatný, zkouším nové přihlášení", xbmc.LOGINFO)
            self._login_from_settings()
            return method(*args, **kwargs)


# --------------------------------------------------------------------------
# Pohledy
# --------------------------------------------------------------------------
def list_root():
    xbmcplugin.setPluginCategory(_HANDLE, _ADDON.getAddonInfo("name"))
    xbmcplugin.setContent(_HANDLE, "videos")

    search_item = xbmcgui.ListItem(label=L(30030))  # Vyhledat
    search_item.setArt({"icon": "DefaultAddonsSearch.png"})
    xbmcplugin.addDirectoryItem(
        _HANDLE, build_url(action="search"), search_item, isFolder=True
    )

    history_item = xbmcgui.ListItem(label=L(30003))  # Historie vyhledávání
    history_item.setArt({"icon": "DefaultAddonHistory.png"})
    xbmcplugin.addDirectoryItem(
        _HANDLE, build_url(action="history"), history_item, isFolder=True
    )

    settings_item = xbmcgui.ListItem(label=L(30033))  # Nastavení
    settings_item.setArt({"icon": "DefaultAddonService.png"})
    xbmcplugin.addDirectoryItem(
        _HANDLE, build_url(action="settings"), settings_item, isFolder=False
    )

    xbmcplugin.endOfDirectory(_HANDLE)


def do_search():
    """Zeptá se na výraz, uloží ho do historie a vypíše výsledky."""
    query = xbmcgui.Dialog().input(L(30031))  # Zadejte hledaný výraz
    if not query:
        xbmcplugin.endOfDirectory(_HANDLE, succeeded=False)
        return
    sort = _default_sort()
    _history().add(query, sort)
    show_results(query, sort, 0)


def show_results(query, sort, offset, update_listing=False):
    """Vykreslí stránku výsledků vyhledávání.

    Když je ``update_listing`` ``True``, nový výpis *nahradí* aktuální položku
    v navigační historii Kodi (místo přidání další úrovně). Používá se při
    úpravě dotazu a změně řazení, aby se uživatel položkou ".." dostal o úroveň
    výš (na kořenové menu), a ne jen "zpět" na předchozí výsledky.
    """
    limit = _results_limit()
    session = Session()
    try:
        data = session.call(
            "search", query, sort=sort, limit=limit, offset=offset
        )
    except AuthenticationError as exc:
        notify(exc.message or L(30050), xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(_HANDLE, succeeded=False)
        return
    except WebshareError as exc:
        _log("Chyba vyhledávání: {0}".format(exc), xbmc.LOGERROR)
        notify(exc.message or L(30050), xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(_HANDLE, succeeded=False)
        return

    xbmcplugin.setPluginCategory(_HANDLE, query)
    xbmcplugin.setContent(_HANDLE, "videos")

    # Položka pro úpravu hledaného dotazu.
    edit_item = xbmcgui.ListItem(
        label="[B]{0}[/B]: {1}".format(L(30042), query)
    )
    edit_item.setArt({"icon": "DefaultAddonsSearch.png"})
    xbmcplugin.addDirectoryItem(
        _HANDLE,
        build_url(action="edit_query", query=query, sort=sort),
        edit_item,
        isFolder=True,
    )

    # Položka pro změnu řazení.
    sort_item = xbmcgui.ListItem(
        label="[B]{0}[/B]: {1}".format(L(30040), sort_label(sort))
    )
    sort_item.setArt({"icon": "DefaultAddonsSearch.png"})
    xbmcplugin.addDirectoryItem(
        _HANDLE,
        build_url(action="change_sort", query=query, sort=sort),
        sort_item,
        isFolder=True,
    )

    files = data.get("files", [])
    for file_info in files:
        _add_file_item(file_info)

    if not files:
        notify(L(30052))  # žádné výsledky

    # Stránkování.
    total = data.get("total", 0)
    if offset + limit < total:
        next_item = xbmcgui.ListItem(label=L(30041))  # Další stránka
        next_item.setArt({"icon": "DefaultFolder.png"})
        xbmcplugin.addDirectoryItem(
            _HANDLE,
            build_url(
                action="results", query=query, sort=sort, offset=offset + limit
            ),
            next_item,
            isFolder=True,
        )

    xbmcplugin.endOfDirectory(_HANDLE, updateListing=update_listing)


def _add_file_item(file_info):
    name = file_info.get("name") or file_info.get("ident")
    size = human_size(file_info.get("size"))
    label = name
    if size:
        label = "{0}  [COLOR grey]({1})[/COLOR]".format(name, size)

    item = xbmcgui.ListItem(label=label)
    item.setProperty("IsPlayable", "true")

    img = file_info.get("img") or file_info.get("stripe")
    if img:
        item.setArt({"thumb": img, "poster": img, "icon": img})

    tag = item.getVideoInfoTag()
    tag.setTitle(name)
    tag.setMediaType("video")
    plot_parts = []
    if size:
        plot_parts.append(size)
    votes = file_info.get("positive_votes", 0) - file_info.get("negative_votes", 0)
    if votes:
        plot_parts.append("{0:+d}".format(votes))
    if plot_parts:
        tag.setPlot("  •  ".join(plot_parts))

    xbmcplugin.addDirectoryItem(
        _HANDLE,
        build_url(action="play", ident=file_info.get("ident"), name=name),
        item,
        isFolder=False,
    )


def play(ident, name=""):
    """Vyřeší přímou URL a spustí přehrávání."""
    if not ident:
        xbmcplugin.setResolvedUrl(_HANDLE, False, xbmcgui.ListItem())
        return
    session = Session()
    try:
        url = session.call("file_link", ident)
    except WebshareError as exc:
        _log("Chyba přehrávání: {0}".format(exc), xbmc.LOGERROR)
        notify(exc.message or L(30053), xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.setResolvedUrl(_HANDLE, False, xbmcgui.ListItem())
        return

    play_item = xbmcgui.ListItem(label=name, path=url)
    xbmcplugin.setResolvedUrl(_HANDLE, True, play_item)


def change_sort(query, current_sort):
    """Nechá vybrat nový způsob řazení a znovu vypíše výsledky."""
    labels = [sort_label(method) for method in SORT_METHODS]
    preselect = SORT_METHODS.index(current_sort) if current_sort in SORT_METHODS else 0
    index = xbmcgui.Dialog().select(L(30040), labels, preselect=preselect)
    if index < 0:
        xbmcplugin.endOfDirectory(_HANDLE, succeeded=False)
        return
    new_sort = SORT_METHODS[index]
    _history().add(query, new_sort)
    show_results(query, new_sort, 0, update_listing=True)


def edit_query(query, sort):
    """Umožní upravit hledaný dotaz a znovu vyhledat.

    Používá se jak z výpisu výsledků, tak z historie vyhledávání – původní
    dotaz se předvyplní do vstupního pole, upravená verze se uloží do historie
    a zobrazí se nová stránka výsledků.
    """
    new_query = xbmcgui.Dialog().input(L(30031), defaultt=query)
    if not new_query:
        xbmcplugin.endOfDirectory(_HANDLE, succeeded=False)
        return
    sort = sort if sort in SORT_METHODS else _default_sort()
    _history().add(new_query, sort)
    show_results(new_query, sort, 0, update_listing=True)


def show_history():
    history = _history()
    entries = history.load()

    xbmcplugin.setPluginCategory(_HANDLE, L(30003))
    xbmcplugin.setContent(_HANDLE, "videos")

    if not entries:
        empty = xbmcgui.ListItem(label=L(30054))  # Historie je prázdná
        xbmcplugin.addDirectoryItem(
            _HANDLE, build_url(action="search"), empty, isFolder=True
        )
        xbmcplugin.endOfDirectory(_HANDLE)
        return

    for entry in entries:
        query = entry["query"]
        sort = entry["sort"]
        label = "{0}  [COLOR grey][{1}][/COLOR]".format(query, sort_label(sort))
        item = xbmcgui.ListItem(label=label)
        item.setArt({"icon": "DefaultAddonsSearch.png"})
        item.addContextMenuItems(
            [
                (
                    L(30042),  # Upravit dotaz
                    "Container.Update({0})".format(
                        build_url(action="edit_query", query=query, sort=sort)
                    ),
                ),
                (
                    L(30040),  # Změnit řazení
                    "Container.Update({0})".format(
                        build_url(action="change_sort", query=query, sort=sort)
                    ),
                ),
                (
                    L(30043),  # Odebrat z historie
                    "RunPlugin({0})".format(
                        build_url(action="history_remove", query=query, sort=sort)
                    ),
                ),
                (
                    L(30044),  # Smazat celou historii
                    "RunPlugin({0})".format(build_url(action="history_clear")),
                ),
            ]
        )
        xbmcplugin.addDirectoryItem(
            _HANDLE,
            build_url(action="results", query=query, sort=sort, offset=0),
            item,
            isFolder=True,
        )

    clear_item = xbmcgui.ListItem(label=L(30044))  # Smazat celou historii
    clear_item.setArt({"icon": "DefaultAddonService.png"})
    xbmcplugin.addDirectoryItem(
        _HANDLE, build_url(action="history_clear"), clear_item, isFolder=False
    )

    xbmcplugin.endOfDirectory(_HANDLE)


def history_remove(query, sort):
    _history().remove(query, sort)
    xbmc.executebuiltin("Container.Refresh")


def history_clear():
    if xbmcgui.Dialog().yesno(_ADDON.getAddonInfo("name"), L(30055)):
        _history().clear()
        xbmc.executebuiltin("Container.Refresh")


def _history():
    return SearchHistory(os.path.join(_profile_dir(), "history.json"))


# --------------------------------------------------------------------------
# Router
# --------------------------------------------------------------------------
def router(paramstring):
    params = dict(parse_qsl(paramstring))
    action = params.get("action")

    if action == "search":
        do_search()
    elif action == "results":
        show_results(
            params.get("query", ""),
            params.get("sort", _default_sort()),
            int(params.get("offset", 0) or 0),
        )
    elif action == "change_sort":
        change_sort(params.get("query", ""), params.get("sort", _default_sort()))
    elif action == "play":
        play(params.get("ident"), params.get("name", ""))
    elif action == "history":
        show_history()
    elif action == "edit_query":
        edit_query(params.get("query", ""), params.get("sort", _default_sort()))
    elif action == "history_remove":
        history_remove(params.get("query", ""), params.get("sort"))
    elif action == "history_clear":
        history_clear()
    elif action == "settings":
        _ADDON.openSettings()
    else:
        list_root()


def run():
    """Vstupní bod volaný z main.py."""
    try:
        router(sys.argv[2][1:])  # odřízne úvodní '?'
    except Exception as exc:  # noqa: BLE001 - globální záchyt kvůli zobrazení detailů
        _show_exception(exc)
