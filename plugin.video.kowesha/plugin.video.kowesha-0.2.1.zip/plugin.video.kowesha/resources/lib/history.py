# -*- coding: utf-8 -*-
"""Perzistence historie vyhledávání.

Historie se ukládá jako JSON seznam do souboru (v Kodi typicky
``special://profile/addon_data/plugin.video.kowesha/history.json``). Modul je
nezávislý na Kodi – přebírá cestu k souboru, takže jde snadno testovat.

Každý záznam má tvar ``{"query": str, "sort": str, "ts": float}``. Seznam je
řazen od nejnovějšího po nejstarší a je deduplikován podle dvojice
(``query``, ``sort``).
"""

import json
import os
import time

DEFAULT_LIMIT = 50


class SearchHistory:
    """Spravuje historii vyhledávání uloženou v jednom JSON souboru."""

    def __init__(self, path, limit=DEFAULT_LIMIT):
        self.path = path
        self.limit = limit

    def load(self):
        """Načte a vrátí seznam záznamů (nejnovější první)."""
        try:
            with open(self.path, "r", encoding="utf-8") as handle:
                data = json.load(handle)
        except (OSError, ValueError):
            return []
        if not isinstance(data, list):
            return []
        # Ponecháme jen validní záznamy s neprázdným dotazem.
        result = []
        for entry in data:
            if isinstance(entry, dict) and entry.get("query"):
                result.append(
                    {
                        "query": str(entry.get("query")),
                        "sort": str(entry.get("sort") or "relevance"),
                        "ts": float(entry.get("ts") or 0),
                    }
                )
        return result

    def save(self, entries):
        """Uloží seznam záznamů na disk (vytvoří i cílovou složku)."""
        directory = os.path.dirname(self.path)
        if directory and not os.path.isdir(directory):
            os.makedirs(directory, exist_ok=True)
        with open(self.path, "w", encoding="utf-8") as handle:
            json.dump(entries[: self.limit], handle, ensure_ascii=False, indent=2)

    def add(self, query, sort="relevance"):
        """Přidá (nebo posune na začátek) záznam a vrátí aktualizovaný seznam."""
        query = (query or "").strip()
        if not query:
            return self.load()
        entries = [
            entry
            for entry in self.load()
            if not (entry["query"] == query and entry["sort"] == sort)
        ]
        entries.insert(0, {"query": query, "sort": sort, "ts": time.time()})
        entries = entries[: self.limit]
        self.save(entries)
        return entries

    def remove(self, query, sort=None):
        """Odstraní záznam(y) daného dotazu (a volitelně konkrétního řazení)."""
        entries = [
            entry
            for entry in self.load()
            if not (
                entry["query"] == query
                and (sort is None or entry["sort"] == sort)
            )
        ]
        self.save(entries)
        return entries

    def clear(self):
        """Smaže celou historii."""
        self.save([])
