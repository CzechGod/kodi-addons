# -*- coding: utf-8 -*-
"""Čistě pythonovská implementace Unixového md5crypt (``$1$``).

Webshare.cz při přihlášení vrací tzv. *salt*, kterým se heslo protáhne přes
klasický Unixový algoritmus ``crypt`` s magií ``$1$`` (md5crypt). Standardní
knihovna Pythonu sice historicky nabízela modul :mod:`crypt`, ten je ale
platformově závislý (nefunguje na Windows) a v Pythonu 3.13 byl odstraněn.
Kvůli přenositelnosti (Kodi běží i na Windows/Androidu) proto používáme tuto
samostatnou implementaci bez externích závislostí.
"""

import hashlib

MAGIC = b"$1$"
ITOA64 = b"./0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"


def _to_bytes(value):
    return value.encode("utf-8") if isinstance(value, str) else value


def _to64(value, length):
    """Zakóduje ``value`` do ``length`` znaků abecedy ITOA64."""
    result = bytearray()
    while length:
        result.append(ITOA64[value & 0x3F])
        value >>= 6
        length -= 1
    return bytes(result)


def md5crypt(password, salt, magic=MAGIC):
    """Vrátí md5crypt hash ve tvaru ``$1$<salt>$<hash>``.

    Parametry ``password`` i ``salt`` mohou být ``str`` i ``bytes``; návratová
    hodnota je vždy ``str`` (ASCII).
    """
    password = _to_bytes(password)
    salt = _to_bytes(salt)
    magic = _to_bytes(magic)

    # Ze saltu odřízneme případnou magii a vše za oddělovačem '$' (max 8 znaků).
    if salt.startswith(magic):
        salt = salt[len(magic):]
    salt = salt.split(b"$", 1)[0][:8]

    ctx = password + magic + salt
    final = hashlib.md5(password + salt + password).digest()

    # Přimíchání "final" po blocích délky hesla.
    pw_len = len(password)
    while pw_len > 0:
        ctx += final if pw_len >= 16 else final[:pw_len]
        pw_len -= 16

    # Přimíchání buď nulového bajtu, nebo prvního znaku hesla podle bitů délky.
    i = len(password)
    while i:
        ctx += b"\x00" if i & 1 else password[:1]
        i >>= 1

    final = hashlib.md5(ctx).digest()

    # 1000 iterací pro zpomalení případného útoku hrubou silou.
    for i in range(1000):
        ctx1 = b""
        ctx1 += password if i & 1 else final
        if i % 3:
            ctx1 += salt
        if i % 7:
            ctx1 += password
        ctx1 += final if i & 1 else password
        final = hashlib.md5(ctx1).digest()

    output = _to64((final[0] << 16) | (final[6] << 8) | final[12], 4)
    output += _to64((final[1] << 16) | (final[7] << 8) | final[13], 4)
    output += _to64((final[2] << 16) | (final[8] << 8) | final[14], 4)
    output += _to64((final[3] << 16) | (final[9] << 8) | final[15], 4)
    output += _to64((final[4] << 16) | (final[10] << 8) | final[5], 4)
    output += _to64(final[11], 2)

    return (magic + salt + b"$" + output).decode("ascii")
