# -*- coding: utf-8 -*-
"""Pomocné funkce nezávislé na Kodi (snadno testovatelné)."""


def human_size(num_bytes):
    """Převede počet bajtů na čitelný řetězec (např. ``1.4 GB``)."""
    try:
        size = float(num_bytes)
    except (TypeError, ValueError):
        return ""
    if size <= 0:
        return ""
    for unit in ("B", "KB", "MB", "GB", "TB", "PB"):
        if size < 1024.0 or unit == "PB":
            if unit == "B":
                return "{0:.0f} {1}".format(size, unit)
            return "{0:.1f} {1}".format(size, unit)
        size /= 1024.0
    return ""
